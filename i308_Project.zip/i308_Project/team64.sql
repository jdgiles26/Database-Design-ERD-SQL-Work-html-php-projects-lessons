-- 1a SELECT
SELECT CONCAT(st.FirstName, ' ',st.LastName) as Students 
FROM Student as st, Section_Grade as sg, Course as c 
WHERE st.StudentID = sg.StudentID 
AND sg.CourseID = c.CourseID 
AND sg.SectionNum = '$section' 
ORDER By st.LastName;

-- 2a SELECT
SELECT c.ClassroomID as Classroom 
FROM Classroom as c, Classroom_Feature as cf 
WHERE cf.ClassroomID = c.ClassroomID 
AND cf.Feature = '$feature';

-- 3b SELECT
SELECT DISTINCT CONCAT (f.FirstName, ' ', f.LastName) as Faculty 
FROM Faculty as f 
WHERE f.FacultyID NOT IN 
(SELECT sg.FacultyID 
FROM Course as c, Section_Grade as sg 
WHERE c.CourseID = sg.CourseID 
AND sg.CourseID = '$course');

-- 5c SELECT for CourseID, Title, LetterGrade
SELECT c.CourseID as CourseID, c.Title as Title, sg.LetterGrade as LetterGrade
FROM Course as c, Student as s, Section as se, Section_Grade as sg
WHERE c.CourseID = sg.CourseID
AND s.StudentID = sg.StudentID
AND se.SectionNum = sg.SectionNum
AND s.StudentID = '$student'
GROUP BY c.Title
ORDER BY se.StartDate;

-- 5c SELECT for overall HoursEarned, GPA
SELECT SUM(CASE WHEN sg.LetterGrade = 'F' THEN 0 ELSE c.CreditHrs END) as HoursEarned, ROUND((SUM(sg.GradePoints)/SUM(CASE WHEN sg.LetterGrade = 'F' THEN 0 ELSE c.CreditHrs END)), 3) as GPA
FROM Course as c, Student as s, Section_Grade as sg
WHERE s.StudentID = sg.StudentID
AND c.CourseID = sg.CourseID
AND s.StudentID = '$student';

-- 7a SELECT 
SELECT CONCAT(s.FirstName,' ',s.LastName) as Student, sm.Major as Major 
FROM Student as s, Advisor as a, Student_Major as sm, Student_Advisor as sa 
WHERE s.StudentID = sa.StudentID 
AND a.AdvisorID = sa.AdvisorID 
AND s.StudentID = sm.StudentID 
AND a.AdvisorID = '$advisor' 
ORDER BY s.LastName;

-- 9b SELECT
SELECT CONCAT(s.FirstName,' ',s.LastName) as StudentName, sm.Major as Major, SUM(CASE WHEN sg.LetterGrade = 'F' THEN 0 ELSE c.CreditHrs END) as HoursEarned, sm.GraduationHrs
FROM Student as s, Course as c, Section_Grade as sg, Student_Major as sm
WHERE s.StudentID = sg.StudentID
AND c.CourseID = sg.CourseID
AND s.StudentID = sm.StudentID
AND sm.Major = '$major'
GROUP BY StudentName
HAVING HoursEarned >= sm.GraduationHrs
ORDER BY HoursEarned DESC;

-- Additional 1 SELECT
SELECT s.FirstName as FirstName, s.LastName as LastName, p.PhoneNum as EmergencyContact
FROM Student as s, Parent as p
WHERE s.StudentID = p.StudentID;

-- Additional 2 SELECT
SELECT s.StudentID as StudentID, p.Name as ParentName, CONCAT(a.FirstName, ' ', a.LastName) as AthleticsAdvisor_Name
FROM Student as s, Parent as p, Student_Advisor as sa, Advisor as a, Advisor_Expertise as ae
WHERE a.AdvisorID = ae.AdvisorID
AND s.StudentID = sa.StudentID
AND a.AdvisorID = sa.AdvisorID
AND s.StudentID = p.StudentID
AND ae.Expertise = 'Athletics';