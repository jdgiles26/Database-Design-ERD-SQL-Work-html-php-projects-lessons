<!doctype html>
<html>
<body>
<h2>Select from Emp_shift</h2>
<h3>Calls same week13.php as in Lecture</h3>
<form action="week13.php" method="POST">
Order Date: <input type="date" name="form-wdate" min="2003-01-02" required><br>
Role: <select name='form-roles'>
<?php
$conn = mysqli_connect("db.soic.indiana.edu","i308_data","my+sql=i308_data","i308_dataset");
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
    $result = mysqli_query($conn,"SELECT distinct role FROM emp_shift");
    while ($row = mysqli_fetch_assoc($result)) {
                  unset($id, $name);
                  $id = $row['role'];
                  $name = $row['role']; 
                  echo '<option value="'.$id.'">'.$name.'</option>';
}
?> 
    </select>
</br>
Time of Order: <input type="time" name="form-wtime" required><br>
<input type="submit" value="Select the Results">
</form>
</body>
</html>
