<?php
$conn=mysqli_connect("db.soic.indiana.edu","i308s19_team64","my+sql=i308s19_team64", "i308s19_team64");

// Check connection
if (!$conn)
    {die("Failed to connect to MySQL: " . mysqli_connect_error()); }
else 
    { echo "" ;}

$student = mysqli_real_escape_string($conn, $_POST['form-student']);

$sql = "SELECT c.CourseID as CourseID, c.Title as Title, sg.LetterGrade as LetterGrade
FROM Course as c, Student as s, Section as se, Section_Grade as sg
WHERE c.CourseID = sg.CourseID
AND s.StudentID = sg.StudentID
AND se.SectionNum = sg.SectionNum
AND s.StudentID = '$student'
GROUP BY c.Title
ORDER BY se.StartDate;";

$sql1 = "SELECT SUM(CASE WHEN sg.LetterGrade = 'F' THEN 0 ELSE c.CreditHrs END) as HoursEarned, ROUND((SUM(sg.GradePoints)/SUM(CASE WHEN sg.LetterGrade = 'F' THEN 0 ELSE c.CreditHrs END)), 3) as GPA
FROM Course as c, Student as s, Section_Grade as sg
WHERE s.StudentID = sg.StudentID
AND c.CourseID = sg.CourseID
AND s.StudentID = '$student';";


$result = mysqli_query($conn,$sql);
$result1 = mysqli_query($conn,$sql1);



if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>CourseID</th><th>Title</th><th>Letter Grade</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo 
"<tr><td>".$row["CourseID"]."</td><td>".$row["Title"]."</td><td>".$row["LetterGrade"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

if ($result1->num_rows > 0) {
    echo "<table border='1'><tr><th>HoursEarned</th><th>GPA</th></tr>";
    // output data of each row
    while($row = $result1->fetch_assoc()) {
        echo 
"<tr><td>".$row["HoursEarned"]."</td><td>".$row["GPA"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}


mysqli_close($conn);
?>

