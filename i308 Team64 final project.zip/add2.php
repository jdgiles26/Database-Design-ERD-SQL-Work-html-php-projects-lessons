<?php
$conn=mysqli_connect("db.soic.indiana.edu","i308s19_team64","my+sql=i308s19_team64", "i308s19_team64");

// Check connection
if (!$conn)
    {die("Failed to connect to MySQL: " . mysqli_connect_error()); }
else 
    { echo "" ;}

$sectionid = mysqli_real_escape_string($conn, $_POST['form-section']);

$sql = "SELECT s.StudentID as StudentID, p.Name as ParentName, CONCAT(a.FirstName, ' ', a.LastName) as AthleticsAdvisor_Name
FROM Student as s, Parent as p, Student_Advisor as sa, Advisor as a, Advisor_Expertise as ae
WHERE a.AdvisorID = ae.AdvisorID
AND s.StudentID = sa.StudentID
AND a.AdvisorID = sa.AdvisorID
AND s.StudentID = p.StudentID
AND ae.Expertise = 'Athletics';";

$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>Student ID</th><th>Parent Name</th><th>AthleticsAdvisor_Name</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo 
"<tr><td>".$row["StudentID"]."</td><td>".$row["ParentName"]."</td><td>".$row["AthleticsAdvisor_Name"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo " 0 results";
}

mysqli_close($conn);
?>

