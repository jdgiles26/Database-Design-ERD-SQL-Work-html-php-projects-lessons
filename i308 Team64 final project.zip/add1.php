<?php
$conn=mysqli_connect("db.soic.indiana.edu","i308s19_team64","my+sql=i308s19_team64", "i308s19_team64");

// Check connection
if (!$conn)
    {die("Failed to connect to MySQL: " . mysqli_connect_error()); }
else 
    { echo "" ;}

$sql = "SELECT s.FirstName as FirstName, s.LastName as LastName, p.PhoneNum as EmergencyContact
FROM Student as s, Parent as p
WHERE s.StudentID = p.StudentID;";

$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>First Name</th><th>Last Name</th><th>Emergency Contact</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo 
"<tr><td>".$row["FirstName"]."</td><td>".$row["LastName"]."</td><td>".$row["EmergencyContact"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo " 0 results";
}
mysqli_close($conn);
?>

