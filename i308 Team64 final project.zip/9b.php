<?php
// database login
$conn=mysqli_connect("db.soic.indiana.edu","i308s19_team64","my+sql=i308s19_team64", "i308s19_team64");

// Check connection
if (!$conn)
    {die("Failed to connect to MySQL: " . mysqli_connect_error()); }
else 
    { echo "" ;}

$major = mysqli_real_escape_string($conn, $_POST['form-major']);

$sql = "SELECT CONCAT(s.FirstName,' ',s.LastName) as StudentName, sm.Major as Major, SUM(CASE WHEN sg.LetterGrade = 'F' THEN 0 ELSE c.CreditHrs END) as HoursEarned, sm.GraduationHrs
FROM Student as s, Course as c, Section_Grade as sg, Student_Major as sm
WHERE s.StudentID = sg.StudentID
AND c.CourseID = sg.CourseID
AND s.StudentID = sm.StudentID
AND sm.Major = '$major'
GROUP BY StudentName
HAVING HoursEarned >= sm.GraduationHrs
ORDER BY HoursEarned DESC;";

$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>Student Name</th><th>Major</th><th>Hours Earned</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo 
"<tr><td>".$row["StudentName"]."</td><td>".$row["Major"]."</td><td>".$row["HoursEarned"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}


mysqli_close($conn);
?>
