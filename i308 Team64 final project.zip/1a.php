<?php
$conn=mysqli_connect("db.soic.indiana.edu","i308s19_team64","my+sql=i308s19_team64", "i308s19_team64");

// Check connection
if (!$conn)
    {die("Failed to connect to MySQL: " . mysqli_connect_error()); }
else 
    { echo "" ;}

$section = mysqli_real_escape_string($conn, $_POST['form-section']);

$sql = "SELECT CONCAT(st.FirstName, ' ',st.LastName) as Students 
FROM Student as st, Section_Grade as sg, Course as c 
WHERE st.StudentID = sg.StudentID 
AND sg.CourseID = c.CourseID 
AND sg.SectionNum = '$section' 
ORDER By st.LastName;";

$result = mysqli_query($conn,$sql);

if ($result->num_rows > 0) {
    echo "<table border='1'><tr><th>Roster</th></tr>";
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo 
"<tr><td>".$row["Students"]."</td></tr>";
    }
    echo "</table>";
} else {
    echo " 0 results";
}
mysqli_close($conn);
?>

