<!doctype html>
<html>
<body>
<!-- Heading -->
<h2>Team 64 Final Project</h2>

<!-- Form 1 for Query 1a -->
<form action="1a.php" method="post">
<b>1a:</b> Produce a roster for a specified section sorted by student’s last name, first name<br>
<i>Hint: use Improving Your Buisness / 11.</i><br>
Course/Section: <select name="form-section" required><br>

<!-- php to fill dropdown -->
<?php
$conn = mysqli_connect("db.soic.indiana.edu","i308s19_team64","my+sql=i308s19_team64","i308s19_team64");
// Check connection
if(!$conn){
	die("Connection failed:" . mysqli_connect_error());
}
$sql = "SELECT DISTINCT CONCAT(c.Title, ' / ',sg.SectionNum) as Section, sg.SectionNum as id 
FROM Section_Grade as sg, Course as c 
WHERE c.CourseID = sg.CourseID 
ORDER BY sg.SectionNum";
$result = mysqli_query($conn,$sql);
	while($row = mysqli_fetch_assoc($result)){
		unset($id,$section);
		$id = $row['id'];
		$section = $row['Section'];
	//takes db info and turns it into html
	echo '<option value="'.$id.'">'.$section.'</option>';
}
?>

</select><br>
<!-- submit button -->
<input type="submit" value="Submit Course/Section">

</form>
<br>
<!-- form 2 for query 2a -->
<form action="2a.php" method="post">
<b>2a:</b> Produce a list of rooms that are equipped with some feature.<br>
<i>Hint: use Projector.</i><br>
Features: <select name="form-features" required><br>

<?php
$conn = mysqli_connect("db.soic.indiana.edu","i308s19_team64","my+sql=i308s19_team64","i308s19_team64");
// Check connection
if(!$conn){
	die("Connection failed:" . mysqli_connect_error());
}
$sql = "SELECT DISTINCT Feature 
FROM Classroom_Feature 
ORDER BY Feature";
$result = mysqli_query($conn,$sql);
	while($row = mysqli_fetch_assoc($result)){
		unset($feature);
		$feature = $row['Feature'];
	//takes db info and turns it into html
	echo '<option value="'.$feature.'">'.$feature.'</option>';
}
?>

</select><br>
<!-- submit button -->
<input type="submit" value="Submit Feature"><br>

</form>
<br>
<!-- form 3 for query 3b -->
<form action="3b.php" method="post">
<b>3b:</b> Produce a list of faculty who have never taught a specified course.<br>
<i>Hint: use Cybersecurity.</i><br>
Course: <select name="form-course" required><br>

<?php
$conn = mysqli_connect("db.soic.indiana.edu","i308s19_team64","my+sql=i308s19_team64","i308s19_team64");
// Check connection
if(!$conn){
	die("Connection failed:" . mysqli_connect_error());
}
$sql = "SELECT DISTINCT CourseID, Title FROM Course ORDER BY CourseID";
$result = mysqli_query($conn,$sql);
	while($row = mysqli_fetch_assoc($result)){
		unset($id,$title);
		$id = $row['CourseID'];
		$title = $row['Title'];
	//takes db info and turns it into html
	echo '<option value="'.$id.'">'.$title.'</option>';
}
?>


</select><br>
<!-- submit button -->
<input type="submit" value="Submit Course">

</form>
<br>
<!-- form 4 for query 5c -->
<form action="5c.php" method="post">
<b>5c:</b> Produce a chronological list of all courses taken by a specified student.<br>
<i>Hint: use Lester Bonafant.</i><br>
Student: <select name="form-student" required><br>

<?php
$conn = mysqli_connect("db.soic.indiana.edu","i308s19_team64","my+sql=i308s19_team64","i308s19_team64");
// Check connection
if(!$conn){
	die("Connection failed:" . mysqli_connect_error());
}
$sql = "SELECT DISTINCT StudentID, CONCAT(FirstName,' ',LastName) AS Name FROM Student ORDER BY StudentID";
$result = mysqli_query($conn,$sql);
	while($row = mysqli_fetch_assoc($result)){
		unset($id,$name);
		$id = $row['StudentID'];
		$name = $row['Name'];
	//takes db info and turns it into html
	echo '<option value="'.$id.'">'.$name.'</option>';
}
?>

</select><br>
<input type="submit" value="Submit Student"><br>
<!-- submit button -->
</form>
<br>
<!-- form 5 for query 7a -->
<form action="7a.php" method="post">
<b>7a:</b> Produce an alphabetical list of students with their majors who are advised by a specific advisor.<br>
<i>Hint: use Kile Elfreda.</i><br>
Advisor: <select name="form-advisor" required>

<?php
$conn = mysqli_connect("db.soic.indiana.edu","i308s19_team64","my+sql=i308s19_team64","i308s19_team64");
// Check connection
if(!$conn){
	die("Connection failed:" . mysqli_connect_error());
}
$sql = "SELECT DISTINCT AdvisorID, CONCAT(FirstName,' ',LastName) AS Name 
FROM Advisor 
ORDER BY AdvisorID";
$result = mysqli_query($conn,$sql);
	while($row = mysqli_fetch_assoc($result)){
		unset($id,$name);
		$id = $row['AdvisorID'];
		$name = $row['Name'];
	//takes db info and turns it into html
	echo '<option value="'.$id.'">'.$name.'</option>';
}
?>

</select><br>
<input type="submit" value="Submit Advisor"><br>
</form>
<br>
<!-- form 6 for query 9b -->
<form action="9b.php" method="post">
<b>9b:</b> Produce a list of students with hours earned who have met graduation requirements for
a specified major.<br>
<i>Hint: use Informatics.</i><br>
Major: <select name="form-major" required><br>

<?php
$conn = mysqli_connect("db.soic.indiana.edu","i308s19_team64","my+sql=i308s19_team64","i308s19_team64");
// Check connection
if(!$conn){
	die("Connection failed:" . mysqli_connect_error());
}
$sql = "SELECT DISTINCT Major 
FROM Student_Major 
ORDER BY Major";
$result = mysqli_query($conn,$sql);
	while($row = mysqli_fetch_assoc($result)){
		unset($major);
		$major = $row['Major'];
	//takes db info and turns it into html
	echo '<option value="'.$major.'">'.$major.'</option>';
}
?>
</select><br>
<input type="submit" value="Submit Major"><br>
</form>
<br>


<!-- additonal queries -->
<form action="add1.php" method="post">
<h2>Additional Queries</h2>
<b>Additional Query 1:</b> For each student, list his/her emergency contact number.<br>

<input type="submit" value="Emergency Contacts"><br>
</form>
<br>
<form action="add2.php" method="post">
<b>Additional Query 2:</b> For each parent of a student athlete, find out his/her child's athletics advisor to learn more about his/her child's progress.<br>
<input type="submit" value="Athletics Advisor"><br>
</form>
</body>
</html>
